# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LAB06

A project using JavaScript to create an HTML Application as a stand-alone .hta file.

Includes:

- simple String manipulation.
- Character coding and decoding through ASCII code values.
- use of the HTA:APPLICATION interface
