# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LAB05

A project to incorporate JavaScript objects.

Includes:

- Using a function as a constructor
- Objects containing:
  - Methods
  - Properties
- Encapsilation for performance