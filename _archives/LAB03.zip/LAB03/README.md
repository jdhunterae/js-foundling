# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LAB03

A project to incorporate simple JavaScript controll structures into a simple text adventure.

Includes:

- `if` statements
- `while` and `for` loops
- `switch` statements
- and `arrays`
