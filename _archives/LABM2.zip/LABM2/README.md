# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LABM2 - Midterm 2 Debugging Section

Contains two files:

- broken.js : which is a copy of the original code with comments regarding what is wrong.
- debug.js : which is a working copy of the corrected code.
