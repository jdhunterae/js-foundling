<?php

$arr = array(
  "item1" => "First array item",
  "item2" => "Second array item",
  "item3" => "Third array item"
  );

echo json_encode($arr);

?>