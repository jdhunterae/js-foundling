# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LAB07

A project using XMLHttpRequest for simple AJAX calls.

Includes:

- AJAX call to a text file.
- AJAX call to a php file.
- non-refreshing page update.
