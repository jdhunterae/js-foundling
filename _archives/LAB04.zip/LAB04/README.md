js-foundling
==============

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

LAB04
--------------
A project to incorporate external JavaScript libraries, specifically jQuery and jQuery-UI
Includes:
- jQuery element wrappers $()
- jQuery element methods
- jQuery-UI functionality:
	- Modal Form
	- CSS animated fading alerts
	- draggable/droppable objects for simple captcha form validation
