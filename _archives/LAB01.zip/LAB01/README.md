js-foundling
==============

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

LAB01
--------------
A project to incorporate simple JavaScript functionality into a page.
Includes:
- document.write() to populate a menu bar/box
- client-side form validation
- user feedback on form validation
