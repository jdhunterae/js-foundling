/**
 * This is the main javascript document.
 **/

function runMe() {
    console.log("It has been run.");
}
