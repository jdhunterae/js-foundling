# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LAB09: Python script to combine all files into a single webpage

Project used to test inserting the contents of a javascript or css file into the position the link holds within an html file for the purposes of testing on multiple computers with different file structures.
