js-foundling
==============

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

LABXX: Final Project
--------------
A project to utilize practices gained through the class.
Includes:
- localStorage of data for on-device application usage.
