# js-foundling

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

## LAB02

A project using JavaScript to create an HTML Application as a stand-alone .hta file.

Includes:

- client-side form validation
- simple math and variable manipulation
- use of the HTA:APPLICATION interface
