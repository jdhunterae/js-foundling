js-foundling
==============

*A repository for all my WSCC DTWP-2350 JavaScript Labs.*

LAB08: Javascript and AJAX
--------------
A project to utilize AJAX for non-refreshing page updates.
Includes:
- AJAX calls for content population.
- pulling information from a php script for a simple text-box hinting function.
